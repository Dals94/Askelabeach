import { useState } from "react";
import { useLocation } from "wouter";
import logoPath from "@assets/IMG_0828.png";

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [, setLocation] = useLocation();

  const navigate = (path: string) => {
    setLocation(path);
    setMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b-2 border-[hsl(var(--hot-pink))]/20">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <button 
            onClick={() => navigate("/")}
            className="flex items-center gap-3 hover:scale-105 transition-transform"
          >
            <img 
              src={logoPath} 
              alt="ASKELABEACH™ Mermaid Logo" 
              className="w-12 h-12 rounded-full object-cover shadow-lg border-2 border-[hsl(var(--hot-pink))]"
            />
            <span className="font-nunito font-bold text-2xl text-[hsl(var(--hot-pink))]">
              ASKELABEACH™
            </span>
          </button>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-4">
            <button 
              onClick={() => navigate("/tiburon")}
              className="bg-[hsl(var(--hot-pink))] text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-pink-600 transition-colors"
            >
              🦈 Tiburón
            </button>
            <button 
              onClick={() => navigate("/profecias")}
              className="bg-[hsl(var(--turquoise))] text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-cyan-600 transition-colors"
            >
              🔮 Profecías
            </button>
            <button 
              onClick={() => navigate("/planner")}
              className="bg-[hsl(var(--sunshine))] text-gray-800 px-4 py-2 rounded-full text-sm font-semibold hover:bg-yellow-500 transition-colors"
            >
              🏝️ Planner
            </button>
            <button 
              onClick={() => navigate("/merch")}
              className="bg-[hsl(var(--coral))] text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-red-400 transition-colors"
            >
              💸 Merch
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-2xl text-[hsl(var(--hot-pink))]"
          >
            ☰
          </button>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 bg-white/20 rounded-lg p-4 space-y-3">
            <button 
              onClick={() => navigate("/tiburon")}
              className="block w-full text-left hover:text-[hsl(var(--sunshine))] transition-colors font-medium"
            >
              🦈 Test del Tiburón
            </button>
            <button 
              onClick={() => navigate("/profecias")}
              className="block w-full text-left hover:text-[hsl(var(--sunshine))] transition-colors font-medium"
            >
              🔮 Profecías
            </button>
            <button 
              onClick={() => navigate("/planner")}
              className="block w-full text-left hover:text-[hsl(var(--sunshine))] transition-colors font-medium"
            >
              🏝️ Planner
            </button>
            <button 
              onClick={() => navigate("/merch")}
              className="block w-full text-left hover:text-[hsl(var(--sunshine))] transition-colors font-medium"
            >
              💸 Merch
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
