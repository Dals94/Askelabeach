import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface MerchProps {
  onBack: () => void;
}

const merchProducts = [
  {
    id: "playera-profecias",
    name: "Playera \"Cambia la Profecía\"",
    description: "Para cuando necesitas que el universo sepa que mandas tú ✨",
    price: "$420 MX",
    emoji: "👕",
    gradient: "from-[hsl(var(--hot-pink))]/20 to-[hsl(var(--turquoise))]/20"
  },
  {
    id: "stickers-tiburon",
    name: "Sticker Pack \"Ali Tiburón Vagina\"",
    description: "5 stickers holográficos para decorar tu laptop con poder místico 🦈",
    price: "$150 MX",
    emoji: "🏷",
    gradient: "from-[hsl(var(--turquoise))]/20 to-[hsl(var(--sunshine))]/20"
  },
  {
    id: "curso-hamaca",
    name: "Curso \"De Alto Valor sin Moverte\"",
    description: "Aprende a ser productiva desde la hamaca. 12 módulos de pura sabiduría 🏖",
    price: "$2,500 MX",
    emoji: "🎓",
    gradient: "from-[hsl(var(--sunshine))]/20 to-[hsl(var(--coral))]/20"
  },
  {
    id: "amuleto-nft",
    name: "Amuleto Digital NFT",
    description: "Protección cósmica para tu wallet. Edición limitada ✨",
    price: "0.1 ETH",
    emoji: "🧿",
    gradient: "from-[hsl(var(--coral))]/20 to-[hsl(var(--lavender))]/20"
  },
  {
    id: "funda-mystic",
    name: "Funda \"Místic Bitch\"",
    description: "Para iPhone y Android. Con cristales de cuarzo fake incluidos 💎",
    price: "$350 MX",
    emoji: "📱",
    gradient: "from-[hsl(var(--lavender))]/20 to-[hsl(var(--mint))]/20"
  },
  {
    id: "hamaca-portatil",
    name: "Hamaca Portátil \"Mimir Profesional\"",
    description: "Para practicar vagancia con propósito en cualquier lugar 🌴",
    price: "$890 MX",
    emoji: "🏖",
    gradient: "from-[hsl(var(--mint))]/20 to-[hsl(var(--hot-pink))]/20"
  }
];

export default function Merch({ onBack }: MerchProps) {
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="flex items-center mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            className="text-[hsl(var(--coral))] hover:bg-[hsl(var(--coral))]/10"
          >
            ← Volver
          </Button>
        </div>
        
        <h2 className="font-nunito font-black text-3xl md:text-5xl text-center text-[hsl(var(--sunshine))] mb-4">
          💸 Askelabeach Merch
        </h2>
        <p className="text-center text-xl text-gray-600 mb-12 font-medium">Productos que no sabías que necesitabas 💅</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {merchProducts.map((product) => (
            <Card key={product.id} className="bg-white/70 rounded-2xl border-2 border-white/30 card-hover mystical-glow">
              <CardContent className="p-6">
                <div className={`bg-gradient-to-br ${product.gradient} h-48 rounded-2xl mb-4 flex items-center justify-center`}>
                  <span className="text-6xl">{product.emoji}</span>
                </div>
                <h3 className="font-nunito font-bold text-xl text-[hsl(var(--hot-pink))] mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-4">{product.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-[hsl(var(--coral))]">{product.price}</span>
                  <Button className="bg-[hsl(var(--hot-pink))] text-white px-4 py-2 rounded-xl font-semibold hover:bg-pink-600 transition-colors">
                    🛒 Quiero
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
