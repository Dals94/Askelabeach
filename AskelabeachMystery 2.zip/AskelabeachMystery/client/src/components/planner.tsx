import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface PlannerProps {
  onBack: () => void;
}

const plannerData = {
  mimir: [
    "10:00 a.m. – Despertar... o intentarlo 😴",
    "11:30 a.m. – Check Instagram en la cama por 'solo 5 minutos' 📱",
    "1:00 p.m. – Brunch tardío porque madrugamos 🥞",
    "3:00 p.m. – Siesta estratégica en la hamaca 🏖",
    "5:00 p.m. – Contemplar el atardecer con drink en mano 🌅",
    "7:00 p.m. – Cenar algo que no requiera cocinar 🍕",
    "9:00 p.m. – Netflix y chill... literal 📺"
  ],
  vagancia: [
    "9:00 a.m. – Yoga en la playa (5 minutos cuenta) 🧘‍♀️",
    "10:30 a.m. – Desayuno consciente viendo el mar 🥝",
    "12:00 p.m. – Caminar por la playa 'ejercitándose' 🚶‍♀️",
    "2:00 p.m. – Leer dos páginas de un libro motivacional 📚",
    "4:00 p.m. – Meditar o pretender que lo haces 🧘",
    "6:00 p.m. – Journaling con frases profundas ✍️",
    "8:00 p.m. – Cena orgánica (o lo que encuentres) 🥗"
  ],
  aventura: [
    "7:00 a.m. – Levantarse temprano como una warrior 💪",
    "8:00 a.m. – Desayuno power antes de la aventura 🥣",
    "9:30 a.m. – Tour en kayak o algo acuático 🚣‍♀️",
    "12:00 p.m. – Almorzar con vista al mar 🌊",
    "2:00 p.m. – Snorkel o actividad marina 🤿",
    "4:00 p.m. – Explorar el pueblo como turista pro 📸",
    "6:00 p.m. – Happy hour merecido 🍹",
    "8:00 p.m. – Cenar mariscos frescos 🦐"
  ]
};

export default function Planner({ onBack }: PlannerProps) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [currentItinerary, setCurrentItinerary] = useState<string[]>([]);
  const [showItinerary, setShowItinerary] = useState(false);

  const selectMood = (mood: string) => {
    setSelectedMood(mood);
    generateItinerary(mood);
  };

  const generateItinerary = (mood: string) => {
    const activities = plannerData[mood as keyof typeof plannerData];
    setCurrentItinerary(activities);
    setShowItinerary(true);
  };

  const generateNewItinerary = () => {
    if (selectedMood) {
      const activities = [...plannerData[selectedMood as keyof typeof plannerData]];
      // Shuffle the activities
      for (let i = activities.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [activities[i], activities[j]] = [activities[j], activities[i]];
      }
      setCurrentItinerary(activities);
    }
  };

  return (
    <section className="py-16 px-4 bg-gradient-to-r from-[hsl(var(--mint))]/20 to-[hsl(var(--lavender))]/20 rounded-3xl">
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            className="text-[hsl(var(--coral))] hover:bg-[hsl(var(--coral))]/10"
          >
            ← Volver
          </Button>
        </div>
        
        <h2 className="font-nunito font-black text-3xl md:text-5xl text-center text-[hsl(var(--coral))] mb-8">
          🏝️ Holbox Caótico Planner
        </h2>
        <p className="text-center text-gray-600 mb-8">Elige tu mood y recibe un itinerario perfectamente caótico 🌴</p>
        
        <Card className="section-card rounded-3xl shadow-2xl mystical-glow">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold text-gray-800 mb-6">¿Cuál es tu mood hoy, reyna?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  onClick={() => selectMood('mimir')}
                  className={`bg-gradient-to-r from-[hsl(var(--lavender))] to-[hsl(var(--turquoise))] text-white font-semibold py-6 px-4 rounded-2xl hover:scale-105 transition-transform shadow-lg border-4 ${
                    selectedMood === 'mimir' ? 'border-[hsl(var(--sunshine))] mystical-glow' : 'border-transparent'
                  }`}
                >
                  😴 Mimir Supremo
                  <br />
                  <span className="text-sm font-normal">Nivel: Koala</span>
                </button>
                <button
                  onClick={() => selectMood('vagancia')}
                  className={`bg-gradient-to-r from-[hsl(var(--coral))] to-[hsl(var(--sunshine))] text-white font-semibold py-6 px-4 rounded-2xl hover:scale-105 transition-transform shadow-lg border-4 ${
                    selectedMood === 'vagancia' ? 'border-[hsl(var(--sunshine))] mystical-glow' : 'border-transparent'
                  }`}
                >
                  🧘‍♀️ Vagancia con Propósito
                  <br />
                  <span className="text-sm font-normal">Nivel: Zen</span>
                </button>
                <button
                  onClick={() => selectMood('aventura')}
                  className={`bg-gradient-to-r from-[hsl(var(--hot-pink))] to-[hsl(var(--mint))] text-white font-semibold py-6 px-4 rounded-2xl hover:scale-105 transition-transform shadow-lg border-4 ${
                    selectedMood === 'aventura' ? 'border-[hsl(var(--sunshine))] mystical-glow' : 'border-transparent'
                  }`}
                >
                  🏄‍♀️ Aventura Básica
                  <br />
                  <span className="text-sm font-normal">Nivel: Turista</span>
                </button>
              </div>
            </div>

            {showItinerary && (
              <div className="bg-white/70 rounded-2xl p-6 border-2 border-[hsl(var(--sunshine))]/30 bounce-in">
                <h4 className="text-2xl font-semibold text-center text-[hsl(var(--hot-pink))] mb-6">Tu Itinerario Caótico:</h4>
                <div className="space-y-4">
                  {currentItinerary.map((activity, index) => (
                    <div 
                      key={index}
                      className="flex items-center bg-gradient-to-r from-white to-[hsl(var(--cream))] p-4 rounded-xl shadow-md border-l-4 border-[hsl(var(--hot-pink))]"
                    >
                      <span className="text-2xl mr-4">{index % 2 === 0 ? '🌊' : '☀️'}</span>
                      <span className="text-lg font-medium text-gray-800">{activity}</span>
                    </div>
                  ))}
                </div>
                <Button 
                  onClick={generateNewItinerary}
                  className="w-full mt-6 bg-[hsl(var(--sunshine))] text-gray-800 px-6 py-3 rounded-full font-semibold hover:bg-yellow-500 transition-colors"
                >
                  🔄 Generar nuevo caos
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
