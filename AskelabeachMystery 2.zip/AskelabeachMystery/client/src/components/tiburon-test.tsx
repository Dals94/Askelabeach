import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface TiburonTestProps {
  onBack: () => void;
}

interface QuizQuestion {
  question: string;
  options: Array<{
    text: string;
    value: number;
  }>;
}

interface QuizResult {
  min: number;
  max: number;
  title: string;
  description: string;
}

const quizData = {
  questions: [
    {
      question: "¿Cómo te sientes cuando alguien menciona 'actividades acuáticas'?",
      options: [
        { text: "¡Emocionada! 🏊‍♀️", value: 3 },
        { text: "Meh, depende del mood 🤷‍♀️", value: 2 },
        { text: "Prefiero mi cama, gracias 😴", value: 1 }
      ]
    },
    {
      question: "Tu outfit ideal para la playa es:",
      options: [
        { text: "Bikini lista para la acción 👙", value: 3 },
        { text: "Vestido cute pero cómodo 👗", value: 2 },
        { text: "Pijama porque #NoMeVoy 👘", value: 1 }
      ]
    },
    {
      question: "¿Qué tan dispuesta estás a lidiar con turistas?",
      options: [
        { text: "Los esquivo como ninja 🥷", value: 3 },
        { text: "Los tolero con sonrisa falsa 😬", value: 2 },
        { text: "Ni loca, me da cringe 😵", value: 1 }
      ]
    },
    {
      question: "Tu relación con los tours es:",
      options: [
        { text: "Los amo, soy turista profesional 📸", value: 3 },
        { text: "Van y vienen, como el amor 💔", value: 2 },
        { text: "Tours = tortura social 😩", value: 1 }
      ]
    },
    {
      question: "Si fueras un animal marino serías:",
      options: [
        { text: "Delfín sociable y aventurero 🐬", value: 3 },
        { text: "Pez tropical medio fancy 🐠", value: 2 },
        { text: "Estrella de mar pegada a su roca ⭐", value: 1 }
      ]
    }
  ],
  results: [
    {
      min: 5, max: 8,
      title: "Quédate a mimir, reyna 👑",
      description: "Tu energía dice 'no today Satan'. Mejor pide un smoothie, ponte tu playlist sad y disfruta el wifi. El tiburón vagina puede esperar hasta que tu alma esté lista. 🌊💤"
    },
    {
      min: 9, max: 12,
      title: "Haz el tour, pero quejarte es parte del viaje 🙄",
      description: "Vas a ir porque FOMO is real, pero tu derecho a quejarte está sagrado. Lleva snacks, audífonos y actitud de 'esto mejor esté bueno'. El drama es opcional pero recomendado. ✨🎭"
    },
    {
      min: 13, max: 15,
      title: "¡Dale que eres toda una aventurera! 🚀",
      description: "Tu vibra dice 'I'm ready'. Ve, disfruta, saca fotos para el Insta y vive tu mejor vida acuática. El tiburón vagina te está esperando con los brazos (¿aletas?) abiertos. 🦈💅"
    }
  ]
};

export default function TiburonTest({ onBack }: TiburonTestProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [totalScore, setTotalScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  const selectAnswer = (value: number) => {
    setIsAnimating(true);
    const newScore = totalScore + value;
    setTotalScore(newScore);
    
    setTimeout(() => {
      if (currentQuestion < quizData.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        setShowResult(true);
      }
      setIsAnimating(false);
    }, 300);
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setTotalScore(0);
    setShowResult(false);
    setIsAnimating(false);
  };

  const getResult = () => {
    return quizData.results.find(r => totalScore >= r.min && totalScore <= r.max) || quizData.results[0];
  };

  const progress = ((currentQuestion + 1) / quizData.questions.length) * 100;

  return (
    <section className="py-16 px-4 bg-gradient-to-r from-[hsl(var(--hot-pink))]/20 to-[hsl(var(--turquoise))]/20 rounded-3xl">
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            className="text-[hsl(var(--hot-pink))] hover:bg-[hsl(var(--hot-pink))]/10"
          >
            ← Volver
          </Button>
        </div>
        
        <h2 className="font-nunito font-black text-3xl md:text-5xl text-center text-[hsl(var(--hot-pink))] mb-8">
          🦈 ¿Voy o no al tiburón vagina?
        </h2>
        
        <Card className="section-card rounded-3xl shadow-2xl mystical-glow">
          <CardContent className="p-8">
            {!showResult ? (
              <div className={`space-y-6 ${isAnimating ? 'opacity-50' : 'opacity-100'} transition-opacity duration-300`}>
                <div className="text-center mb-8">
                  <div className="inline-block bg-[hsl(var(--hot-pink))] text-white px-6 py-2 rounded-full font-semibold text-lg">
                    Pregunta {currentQuestion + 1} de {quizData.questions.length}
                  </div>
                </div>
                
                <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                  <div 
                    className="bg-gradient-to-r from-[hsl(var(--hot-pink))] to-[hsl(var(--turquoise))] h-3 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
                
                <h3 className="text-2xl font-semibold text-center mb-8 text-gray-800">
                  {quizData.questions[currentQuestion].question}
                </h3>
                
                <div className="space-y-4">
                  {quizData.questions[currentQuestion].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => selectAnswer(option.value)}
                      disabled={isAnimating}
                      className="w-full bg-gradient-to-r from-[hsl(var(--coral))] to-[hsl(var(--sunshine))] text-white font-semibold py-4 px-6 rounded-2xl text-lg hover:scale-105 transition-transform shadow-lg disabled:opacity-50"
                    >
                      {option.text}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center bounce-in">
                <div className="text-6xl mb-6 animate-pulse-slow">🎉</div>
                <h3 className="font-nunito font-black text-3xl text-[hsl(var(--hot-pink))] mb-4">Tu Veredicto:</h3>
                <div className="bg-gradient-to-r from-[hsl(var(--lavender))]/50 to-[hsl(var(--mint))]/50 rounded-2xl p-8 mb-6">
                  <p className="text-2xl font-semibold text-gray-800 mb-4">{getResult().title}</p>
                  <p className="text-lg text-gray-600">{getResult().description}</p>
                </div>
                <Button 
                  onClick={restartQuiz}
                  className="bg-gradient-to-r from-[hsl(var(--hot-pink))] to-[hsl(var(--turquoise))] text-white font-bold py-4 px-8 rounded-2xl text-lg hover:scale-105 transition-transform shadow-lg"
                >
                  🔄 Hacerlo de nuevo (pero mejor)
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
