import { useState, useEffect } from "react";
import TiburonTest from "@/components/tiburon-test";
import Profecias from "@/components/profecias";
import Planner from "@/components/planner";
import Merch from "@/components/merch";
import logoPath from "@assets/IMG_0828.png";

interface HomeProps {
  initialSection?: string;
}

export default function Home({ initialSection = "home" }: HomeProps) {
  const [activeSection, setActiveSection] = useState(initialSection);

  useEffect(() => {
    if (initialSection !== "home") {
      setActiveSection(initialSection);
    }
  }, [initialSection]);

  return (
    <div className="pt-20 pb-8 px-4">
      {/* Home Section */}
      {activeSection === "home" && (
        <section className="section-card rounded-3xl p-8 mx-auto max-w-4xl mb-8 text-center">
          <div className="bounce-in">
            <div className="flex items-center justify-center mb-6">
              <img 
                src={logoPath} 
                alt="ASKELABEACH™ Mermaid Logo" 
                className="w-20 h-20 md:w-24 md:h-24 rounded-full object-cover shadow-2xl border-4 border-[hsl(var(--hot-pink))] mystical-glow mr-4"
              />
              <h1 className="font-nunito font-black text-4xl md:text-6xl text-[hsl(var(--hot-pink))]">
                ASKELABEACH™
              </h1>
            </div>
            <p className="font-caveat text-2xl md:text-3xl text-[hsl(var(--turquoise))] mb-6">
              Tu super app mística y empoderadora 🌊✨
            </p>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Descubre si debes ir al tiburón vagina, recibe profecías divinas, planea tu caos en Holbox y compra merch que no sabías que necesitabas 💅
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              <button 
                onClick={() => setActiveSection("tiburon")}
                className="bg-gradient-to-r from-[hsl(var(--hot-pink))] to-pink-400 text-white py-4 px-6 rounded-2xl font-bold text-lg hover:scale-105 transform transition-all duration-200 mystical-glow"
              >
                🦈<br />Test del Tiburón
              </button>
              <button 
                onClick={() => setActiveSection("profecias")}
                className="bg-gradient-to-r from-[hsl(var(--turquoise))] to-cyan-400 text-white py-4 px-6 rounded-2xl font-bold text-lg hover:scale-105 transform transition-all duration-200"
              >
                🔮<br />Profecías
              </button>
              <button 
                onClick={() => setActiveSection("planner")}
                className="bg-gradient-to-r from-[hsl(var(--sunshine))] to-yellow-400 text-gray-800 py-4 px-6 rounded-2xl font-bold text-lg hover:scale-105 transform transition-all duration-200"
              >
                🏝️<br />Planner Caótico
              </button>
              <button 
                onClick={() => setActiveSection("merch")}
                className="bg-gradient-to-r from-[hsl(var(--coral))] to-red-400 text-white py-4 px-6 rounded-2xl font-bold text-lg hover:scale-105 transform transition-all duration-200"
              >
                💸<br />Merch Divino
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Individual Sections */}
      {activeSection === "tiburon" && <TiburonTest onBack={() => setActiveSection("home")} />}
      {activeSection === "profecias" && <Profecias onBack={() => setActiveSection("home")} />}
      {activeSection === "planner" && <Planner onBack={() => setActiveSection("home")} />}
      {activeSection === "merch" && <Merch onBack={() => setActiveSection("home")} />}

      {/* Footer */}
      <footer className="gradient-bg text-white py-12 px-4 mt-16 rounded-t-3xl">
        <div className="container mx-auto text-center">
          <h3 className="font-nunito font-bold text-2xl mb-4">🏖️ ASKELABEACH™</h3>
          <p className="text-lg mb-6">Donde el caos se vuelve sabiduría cósmica ✨</p>
          <div className="flex justify-center space-x-6 text-2xl mb-8">
            <span className="hover:text-[hsl(var(--sunshine))] transition-colors cursor-pointer">📱</span>
            <span className="hover:text-[hsl(var(--sunshine))] transition-colors cursor-pointer">💌</span>
            <span className="hover:text-[hsl(var(--sunshine))] transition-colors cursor-pointer">🌟</span>
          </div>
          <p className="text-sm opacity-80">
            © 2024 ASKELABEACH™ - Todos los derechos reservados para la vagancia con propósito 🏝️
          </p>
        </div>
      </footer>
    </div>
  );
}
