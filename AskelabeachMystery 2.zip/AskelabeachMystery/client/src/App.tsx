import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Navigation from "@/components/navigation";

function Router() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/tiburon" component={() => <Home initialSection="tiburon" />} />
        <Route path="/profecias" component={() => <Home initialSection="profecias" />} />
        <Route path="/planner" component={() => <Home initialSection="planner" />} />
        <Route path="/merch" component={() => <Home initialSection="merch" />} />
        <Route component={Home} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
