# ASKELABEACH™ 🏖️

Una super app web divertida y mística con 4 secciones interactivas: test de decisiones, profecías aleatorias, planner caótico y merch mockup, todo con estética femenina y playera.

## 🌊 Características

- **🦈 Test del Tiburón Vagina**: Test interactivo para decidir si debes ir o no
- **🔮 Profecías Monzebitch**: Generador de profecías místicas aleatorias
- **🏝️ Holbox Caótico Planner**: Planificador de actividades según tu mood
- **💸 Askelabeach Merch**: Mockup de productos divertidos

## 🚀 Desplegar en GitHub Pages

1. **Subir archivos a GitHub:**
   - Crea un nuevo repositorio en GitHub
   - Sube todos los archivos de este proyecto al repositorio

2. **Activar GitHub Pages:**
   - Ve a Settings > Pages en tu repositorio
   - En "Source", selecciona "Deploy from a branch"
   - Selecciona la rama "main" y carpeta "/ (root)"
   - Guarda los cambios

3. **¡Listo!** Tu app estará disponible en:
   `https://tu-usuario.github.io/nombre-del-repositorio`

## 📁 Estructura del Proyecto

```
/
├── index.html          # Página principal
├── styles.css          # Estilos CSS
├── script.js           # Funcionalidad JavaScript
├── data.js             # Datos del contenido
├── assets/             # Imágenes y recursos
│   └── logo.png        # Logo de la sirena
└── README.md           # Esta guía
```

## ✨ Personalización

### Agregar nuevas profecías
Edita el archivo `data.js` y añade frases al array `prophecies`:

```javascript
const prophecies = [
    "Tu nueva profecía aquí 🌟",
    // ... más profecías
];
```

### Modificar preguntas del test
En `data.js`, edita el objeto `quizData.questions`:

```javascript
{
    id: "q6",
    text: "Tu nueva pregunta aquí?",
    options: [
        { text: "Opción 1 🎯", value: 3 },
        { text: "Opción 2 🤔", value: 2 },
        { text: "Opción 3 😴", value: 1 }
    ]
}
```

### Agregar productos de merch
En `data.js`, añade productos al array `merchProducts`:

```javascript
{
    id: "nuevo-producto",
    name: "Nombre del Producto",
    description: "Descripción divertida",
    price: "$XX MX",
    emoji: "🎁",
    gradient: "linear-gradient(135deg, color1, color2)"
}
```

### Modificar actividades del planner
En `data.js`, edita las actividades en `plannerData`:

```javascript
plannerData.mimir.push("Nueva actividad para mood mimir 😴");
```

## 🎨 Colores y Estética

Los colores principales están definidos en `styles.css`:
- **Hot Pink**: #E91E63
- **Turquoise**: #00E5FF  
- **Sunshine**: #FFD700
- **Coral**: #FF7F7F
- **Lavender**: #E6E6FA
- **Mint**: #98FB98

## 📱 Responsive Design

La app está optimizada para:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (hasta 767px)

## 🌟 Sin Dependencias

Esta versión es completamente estática y no requiere:
- Node.js
- npm install
- Servidor de desarrollo
- Build process

Solo abre `index.html` en tu navegador o despliega directamente en GitHub Pages.

---

*© 2024 ASKELABEACH™ - Todos los derechos reservados para la vagancia con propósito 🏝️*