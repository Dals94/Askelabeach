import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ProfeciasProps {
  onBack: () => void;
}

const prophecies = [
  "Del rancho al primer mundo con una green card emocional 🌟",
  "La pereza es un acto de autocuidado superior 🧘‍♀️",
  "Tu ex va a stalkear tu story justo cuando subas algo cute 👀",
  "Hoy vas a encontrar dinero que no sabías que tenías 💰",
  "El universo conspira para que tu crush te mande mensaje... en 3 días ⏰",
  "Tu café de mañana va a estar perfectamente preparado ☕",
  "Alguien va a cancelar planes y vas a fingir que te molesta pero secretamente celebrar 🎉",
  "Tu skincare routine finalmente va a dar resultados visibles ✨",
  "Vas a encontrar el outfit perfecto en tu clóset... otra vez 👗",
  "Tu mamá va a llamarte justo cuando estés haciendo algo importante 📞",
  "Hoy es día de manifestar abundancia desde la cama 🛏",
  "El algoritmo va a bendecirte con el TikTok perfecto 📱",
  "Tu mascota va a hacer algo súper cute que vas a grabar 🐕",
  "Vas a recordar una conversación cringe de hace 5 años... a las 3am 😅",
  "El delivery va a llegar antes de lo esperado 🚚"
];

export default function Profecias({ onBack }: ProfeciasProps) {
  const [currentProphecy, setCurrentProphecy] = useState(
    "✨ Presiona el botón para recibir tu profecía cósmica ✨"
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [lastProphecyIndex, setLastProphecyIndex] = useState(-1);

  const generateProphecy = () => {
    setIsGenerating(true);
    
    setTimeout(() => {
      let randomIndex;
      do {
        randomIndex = Math.floor(Math.random() * prophecies.length);
      } while (randomIndex === lastProphecyIndex && prophecies.length > 1);
      
      setLastProphecyIndex(randomIndex);
      setCurrentProphecy(prophecies[randomIndex]);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <section className="py-16 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            className="text-[hsl(var(--turquoise))] hover:bg-[hsl(var(--turquoise))]/10"
          >
            ← Volver
          </Button>
        </div>
        
        <h2 className="font-nunito font-black text-3xl md:text-5xl text-center text-[hsl(var(--turquoise))] mb-8">
          🔮 Profecías Monzebitch
        </h2>
        <p className="text-center text-gray-600 mb-8">Recibe sabiduría cósmica directamente del universo de WhatsApp ✨</p>
        
        <Card className="section-card rounded-3xl shadow-2xl mystical-glow">
          <CardContent className="p-8 text-center">
            <div className={`bg-gradient-to-r from-[hsl(var(--lavender))]/50 to-[hsl(var(--mint))]/50 rounded-2xl p-8 mb-8 min-h-[200px] flex items-center justify-center ${isGenerating ? 'shake' : ''}`}>
              <p className="font-caveat text-2xl md:text-3xl text-gray-800 leading-relaxed">
                {isGenerating ? "🔮 El universo está conspirando... 🔮" : currentProphecy}
              </p>
            </div>
            
            <Button
              onClick={generateProphecy}
              disabled={isGenerating}
              className={`bg-gradient-to-r from-[hsl(var(--turquoise))] to-[hsl(var(--hot-pink))] text-white px-12 py-4 rounded-full text-xl font-bold hover:scale-105 transform transition-all duration-200 shadow-lg disabled:opacity-50 ${isGenerating ? 'animate-wiggle' : ''}`}
            >
              ✨ Cámbiame la vibra ✨
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
