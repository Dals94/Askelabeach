import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Quiz data endpoint
  app.get("/api/quiz", async (req, res) => {
    try {
      const quizData = await storage.getQuizData();
      res.json(quizData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quiz data" });
    }
  });

  // Prophecies endpoint
  app.get("/api/prophecies", async (req, res) => {
    try {
      const prophecies = await storage.getProphecies();
      res.json(prophecies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch prophecies" });
    }
  });

  // Random prophecy endpoint
  app.get("/api/prophecies/random", async (req, res) => {
    try {
      const prophecies = await storage.getProphecies();
      const randomProphecy = prophecies[Math.floor(Math.random() * prophecies.length)];
      res.json(randomProphecy);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch random prophecy" });
    }
  });

  // Planner activities endpoint
  app.get("/api/planner", async (req, res) => {
    try {
      const activities = await storage.getPlannerActivities();
      res.json(activities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch planner activities" });
    }
  });

  // Planner activities by mood endpoint
  app.get("/api/planner/:mood", async (req, res) => {
    try {
      const { mood } = req.params;
      const activities = await storage.getPlannerActivities();
      const moodActivities = activities.find(a => a.mood === mood);
      
      if (!moodActivities) {
        return res.status(404).json({ error: "Mood not found" });
      }
      
      res.json(moodActivities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch mood activities" });
    }
  });

  // Merch products endpoint
  app.get("/api/merch", async (req, res) => {
    try {
      const products = await storage.getMerchProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch merch products" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
