import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Schema for quiz questions and results
export const quizQuestionSchema = z.object({
  id: z.string(),
  text: z.string(),
  options: z.array(z.object({
    text: z.string(),
    value: z.number()
  }))
});

export const quizResultSchema = z.object({
  min: z.number(),
  max: z.number(),
  title: z.string(),
  description: z.string()
});

// Schema for prophecies
export const prophecySchema = z.object({
  id: z.string(),
  text: z.string()
});

// Schema for planner activities
export const plannerActivitySchema = z.object({
  mood: z.enum(['mimir', 'vagancia', 'aventura']),
  activities: z.array(z.string())
});

// Schema for merch products
export const merchProductSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  price: z.string(),
  emoji: z.string(),
  gradient: z.string()
});

export type QuizQuestion = z.infer<typeof quizQuestionSchema>;
export type QuizResult = z.infer<typeof quizResultSchema>;
export type Prophecy = z.infer<typeof prophecySchema>;
export type PlannerActivity = z.infer<typeof plannerActivitySchema>;
export type MerchProduct = z.infer<typeof merchProductSchema>;

// User table (keeping existing structure)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
